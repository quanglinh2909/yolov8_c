# FF-RKNN Portable Package

This is a portable build of ff-rknn that should run on ARM64 Linux systems without requiring complex installation.

## System Requirements

- ARM64 (aarch64) Linux system
- Kernel with DRM/KMS support
- GPU drivers (Mali/Panfrost for RK3588)
- Basic system libraries (glibc, libm, libpthread)

## Installation

1. Extract this package to any directory
2. Make sure you have RKNN model files in the models/ directory
3. Run with: `./ff-rknn [options]`

## Usage Examples

```bash
# Basic camera detection
./ff-rknn -i /dev/video0 -f v4l2 -m models/yolov8n.rknn -track true

# RTSP stream with mask detection  
./ff-rknn -f rtsp -i rtsp://192.168.1.100:554/stream \
          -m models/yolov8n.rknn \
          -mask-model models/face_mask.rknn \
          -track true -mask-history 5

# Headless mode (no display)
./ff-rknn -f rtsp -i rtsp://camera -m models/yolov8n.rknn \
          -track true -headless true
```

## Troubleshooting

If you get library errors, try:
```bash
export LD_LIBRARY_PATH=$(pwd)/lib:$LD_LIBRARY_PATH
./bin/ff-rknn [options]
```

Built on: Thu Oct 23 11:26:43 +07 2025
Architecture: aarch64

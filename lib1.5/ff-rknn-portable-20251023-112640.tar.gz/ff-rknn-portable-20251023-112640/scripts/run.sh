#!/bin/bash
# Mask Detection with Two Models (Person + Face Mask)
# Display Mode: Shows UI window (-headless false)
# Background Mode: No UI, processing only (-headless true)

# Camera Configuration
RTSP_URL="rtsp://admin:Oryza123@192.168.103.241:554/cam/realmonitor?channel=1&subtype=0"

# Model Paths
PERSON_MODEL="./model/RK3588/yolov8.rknn"
MASK_MODEL="./model/RK3588/face_mask.rknn"

# Display Configuration
WIDTH=960
HEIGHT=540
FPS=15

echo "😷 Starting Mask Detection System"
echo "=================================="
echo "Mode: DISPLAY (UI Window)"
echo "Camera: $RTSP_URL"
echo "Person Model: $PERSON_MODEL"
echo "Mask Model: $MASK_MODEL"
echo "Resolution: ${WIDTH}x${HEIGHT}"
echo "FPS Cap: $FPS"
echo ""

# Run with both models - DISPLAY MODE (default)
./ff-rknn \
    -f rtsp \
    -i "$RTSP_URL" \
    -x $WIDTH -y $HEIGHT \
    -m "$PERSON_MODEL" \
    -mask-model "$MASK_MODEL" \
    -fps $FPS \
    -track true \
    -headless false \
    -mask-history 8

# Optional: Add ROI zones (uncomment to use)
#  -roi "[[516, 442], [1060, 470], [1025, 901], [403, 814]];[[1306, 479], [1723, 481], [1818, 944], [1272, 895]]" \
#  -roi-overlap 1

# Explanation of polygon points (for 960x540 display):
# Point 1: (263, 167) - Top left
# Point 2: (832, 197) - Top right  
# Point 3: (835, 497) - Bottom right
# Point 4: (313, 530) - Bottom left
# Creates a trapezoid shape (wider at bottom)

# Example 2: Multiple polygon zones
# Zone 1: Left lane trapezoid
# Zone 2: Right lane trapezoid
# ./ff-rknn \
#     -f rtsp \
#     -i "rtsp://..." \
#     -x 960 -y 540 \
#     -m ./model/RK3588/yolov8.rknn \
#     -fps 15 \
#     -track true \
#     -roi "[[100,200],[400,200],[450,500],[50,500]];[[500,200],[850,200],[900,500],[450,500]]"

# Example 3: Triangle zone (for corner coverage)
# ./ff-rknn \
#     -f rtsp \c
#     -i "rtsp://..." \
#     -x 960 -y 540 \
#     -m ./model/RK3588/yolov8.rknn \
#     -fps 15 \
#     -track true \
#     -roi "[[480,100],[800,400],[160,400]]"

# Example 4: Complex 6-point polygon (irregular area)
# ./ff-rknn \
#     -f rtsp \
#     -i "rtsp://..." \
#     -x 960 -y 540 \
#     -m ./model/RK3588/yolov8.rknn \
#     -fps 15 \
#     -track true \
#     -roi "[[200,100],[400,150],[600,200],[550,450],[250,500],[150,300]]"

# Note: Polygon coordinates are based on your display resolution (-x and -y)
# For 960x540: x is 0-960, y is 0-540
# For 1920x1080: x is 0-1920, y is 0-1080

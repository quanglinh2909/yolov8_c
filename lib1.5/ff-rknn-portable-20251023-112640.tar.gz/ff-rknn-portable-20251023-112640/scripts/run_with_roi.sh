#!/bin/bash
# Mask detection with ROI zones

./ff-rknn \
    -f rtsp \
    -i "rtsp://admin:Oryza123@192.168.103.241:554/cam/realmonitor?channel=1&subtype=0" \
    -x 960 -y 540 \
    -m ./model/RK3588/yolov8.rknn \
    -mask-model ./model/RK3588/face_mask.rknn \
    -fps 15 \
    -track true \
    -roi "[[516, 442], [1060, 470], [1025, 901], [403, 814]]" \
    -roi-overlap 1

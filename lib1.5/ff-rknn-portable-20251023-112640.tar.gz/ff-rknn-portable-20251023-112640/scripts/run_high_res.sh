#!/bin/bash
# High resolution mask detection (slower but more accurate)

./ff-rknn \
    -f rtsp \
    -i "rtsp://admin:Oryza123@192.168.103.241:554/cam/realmonitor?channel=1&subtype=0" \
    -x 1920 -y 1080 \
    -m ./model/RK3588/yolov8.rknn \
    -mask-model ./model/RK3588/face_mask.rknn \
    -fps 10 \
    -track true

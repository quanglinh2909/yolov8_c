#!/bin/bash
# Mask Detection with Display UI Window

# Camera Configuration
RTSP_URL="rtsp://admin:Oryza123@192.168.103.241:554/cam/realmonitor?channel=1&subtype=0"

# Model Paths
PERSON_MODEL="./model/RK3588/yolov8.rknn"
MASK_MODEL="./model/RK3588/face_mask.rknn"

# Display Configuration
WIDTH=960
HEIGHT=540
FPS=15

echo "😷 Starting Mask Detection System"
echo "=================================="
echo "Mode: DISPLAY (UI Window)"
echo "Camera: $RTSP_URL"
echo "Person Model: $PERSON_MODEL"
echo "Mask Model: $MASK_MODEL"
echo "Resolution: ${WIDTH}x${HEIGHT}"
echo "FPS Cap: $FPS"
echo ""

# Run with both models - DISPLAY MODE (shows UI)
./ff-rknn \
    -f rtsp \
    -i "$RTSP_URL" \
    -x $WIDTH -y $HEIGHT \
    -m "$PERSON_MODEL" \
    -mask-model "$MASK_MODEL" \
    -fps $FPS \
    -track true \
    -headless false

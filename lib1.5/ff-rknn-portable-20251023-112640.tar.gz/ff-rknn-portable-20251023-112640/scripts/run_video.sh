#!/bin/bash
# Test with video file instead of RTSP

VIDEO_FILE="${1:-test_video.mp4}"

if [ ! -f "$VIDEO_FILE" ]; then
    echo "❌ Video file not found: $VIDEO_FILE"
    echo "Usage: ./run_video.sh <path_to_video.mp4>"
    exit 1
fi

echo "📹 Testing with video: $VIDEO_FILE"
echo ""

./ff-rknn \
    -i "$VIDEO_FILE" \
    -x 960 -y 540 \
    -m ./model/RK3588/yolov8.rknn \
    -mask-model ./model/RK3588/face_mask.rknn \
    -fps 15 \
    -track true

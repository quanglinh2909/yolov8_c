#!/bin/bash
# Mask Detection with Two Models (Person + Face Mask)

# ============================================
# CAMERA CONFIGURATION
# ============================================
RTSP_URL="rtsp://admin:Oryza@123@192.168.104.101:554/cam/realmonitor?channel=1&subtype=0"

# ============================================
# MODEL CONFIGURATION
# ============================================
PERSON_MODEL="./model/RK3588/yolov8.rknn"
MASK_MODEL="./model/RK3588/face_mask.rknn"

# ============================================
# DISPLAY CONFIGURATION
# ============================================
WIDTH=960
HEIGHT=540
FPS=15

# ============================================
# CONFIDENCE THRESHOLDS
# ============================================
# Person Detection Confidence (0.0-1.0)
# Cao hơn = ít false positive, nhưng có thể bỏ sót người thật
# Thấp hơn = phát hiện nhiều hơn, nhưng có thể có false positive
PERSON_CONF=0.5

# Mask Detection Confidence (0.0-1.0)
# Cao hơn = chỉ cảnh báo khi chắc chắn về trạng thái khẩu trang
# Thấp hơn = nhạy hơn nhưng có thể cảnh báo nhầm
MASK_CONF=0.7

# Tracking Confirmation Confidence (0.0-1.0)
# Đây là ngưỡng HIGH_CONF để confirm một track
# Yêu cầu: 3 frame liên tiếp có confidence >= TRACK_CONF để confirm
# Cao hơn (0.9) = chỉ confirm track khi RẤT chắc chắn, ít ID switch
# Thấp hơn (0.6-0.7) = confirm nhanh hơn, có thể có nhiều ID switch hơn
# Mặc định 0.8 = cân bằng tốt giữa độ chính xác và tốc độ confirm
# 
# LOW_CONF được tự động tính = TRACK_CONF * 0.375
# Ví dụ: TRACK_CONF=0.8 → LOW_CONF=0.3
# Track sẽ được duy trì nếu confidence >= LOW_CONF
TRACK_CONF=0.8

# ============================================
# TRACKING CONFIGURATION
# ============================================
ENABLE_TRACKING=true

# ============================================
# ROI (Region of Interest) CONFIGURATION
# ============================================
# Uncomment and modify to enable ROI zones
# Format 1 - Rectangle (normalized 0.0-1.0): "x,y,width,height"
# Format 2 - Polygon (pixel coords): "[[x1,y1],[x2,y2],[x3,y3],[x4,y4]]"
# Multiple zones: separate with semicolon ;

# ROI_ZONES=""
# Example single polygon zone:
# ROI_ZONES="[[516,442],[1060,470],[1025,901],[403,814]]"

# Example multiple polygon zones:
# ROI_ZONES="[[516,442],[1060,470],[1025,901],[403,814]];[[1306,479],[1723,481],[1818,944],[1272,895]]"

# ROI Overlap Mode (0-100)
# 0 = center point must be in ROI (default, fastest)
# 50 = 50% of bounding box must overlap ROI (balanced)
# 80 = 80% of bounding box must overlap ROI (strict)
ROI_OVERLAP=0

# ============================================
# ADVANCED CONFIGURATION
# ============================================
# Screen position (left, top in pixels)
SCREEN_LEFT=0
SCREEN_TOP=0

# FPS Drop Mode (0 or 1)
# 0 = only throttle processing
# 1 = also drop decode packets to enforce FPS cap
FPS_DROP_MODE=0

# ============================================

echo "😷 Starting Mask Detection System"
echo "=================================="
echo "Camera: $RTSP_URL"
echo "Person Model: $PERSON_MODEL"
echo "Mask Model: $MASK_MODEL"
echo "Resolution: ${WIDTH}x${HEIGHT}"
echo "FPS Cap: $FPS"
echo ""
echo "Confidence Thresholds:"
echo "  Person Detection: $PERSON_CONF ($(echo "$PERSON_CONF * 100" | bc)%)"
echo "  Mask Detection:   $MASK_CONF ($(echo "$MASK_CONF * 100" | bc)%)"
echo "  Track Confirm:    $TRACK_CONF ($(echo "$TRACK_CONF * 100" | bc)%)"
echo ""

# Run with both models
./ff-rknn1 \
    -f rtsp \
    -i "$RTSP_URL" \
    -x $WIDTH -y $HEIGHT \
    -l $SCREEN_LEFT -t $SCREEN_TOP \
    -m "$PERSON_MODEL" \
    -mask-model "$MASK_MODEL" \
    -fps $FPS \
    -Fd $FPS_DROP_MODE \
    -track $ENABLE_TRACKING \
    -person-conf $PERSON_CONF \
    -mask-conf $MASK_CONF \
    -track-conf $TRACK_CONF

# Add ROI zones if configured
# Uncomment the lines below to enable ROI
# ./ff-rknn \
#     -f rtsp \
#     -i "$RTSP_URL" \
#     -x $WIDTH -y $HEIGHT \
#     -l $SCREEN_LEFT -t $SCREEN_TOP \
#     -m "$PERSON_MODEL" \
#     -mask-model "$MASK_MODEL" \
#     -fps $FPS \
#     -Fd $FPS_DROP_MODE \
#     -track $ENABLE_TRACKING \
#     -person-conf $PERSON_CONF \
#     -mask-conf $MASK_CONF \
#     -track-conf $TRACK_CONF \
#     -roi "$ROI_ZONES" \
#     -roi-overlap $ROI_OVERLAP

# ============================================
# EXAMPLES & DOCUMENTATION
# ============================================

# Example 1: Simple rectangle ROI (normalized coordinates)
# ROI_ZONES="0.2,0.3,0.6,0.5"  # x=20%, y=30%, width=60%, height=50%

# Example 2: Single polygon zone (pixel coordinates for 960x540)
# ROI_ZONES="[[263,167],[832,197],[835,497],[313,530]]"
# Creates a trapezoid shape (wider at bottom)

# Example 3: Multiple polygon zones (left and right lanes)
# ROI_ZONES="[[516,442],[1060,470],[1025,901],[403,814]];[[1306,479],[1723,481],[1818,944],[1272,895]]"

# Example 4: Triangle zone (for corner coverage)
# ROI_ZONES="[[480,100],[800,400],[160,400]]"

# Example 5: Complex 6-point polygon (irregular area)
# ROI_ZONES="[[200,100],[400,150],[600,200],[550,450],[250,500],[150,300]]"

# ============================================
# TUNING TIPS
# ============================================
# 
# PERSON_CONF (Person Detection):
#   0.25 (default) - Balanced, good for most cases
#   0.5-0.7        - Reduce false positives, better for crowded areas
#   0.1-0.2        - Detect more people, but may have false positives
#
# MASK_CONF (Mask Detection):
#   0.25 (default) - Balanced
#   0.6-0.8        - Only alert when very confident about mask status
#   0.1-0.3        - More sensitive, faster alerts but may be noisy
#
# TRACK_CONF (Tracking Confirmation):
#   0.8 (default)  - Require high confidence to confirm a track
#   0.6-0.7        - Faster track confirmation, may have more ID switches
#   0.9            - Very strict, only confirm very stable tracks
#
# FPS:
#   15             - Good balance of performance and accuracy
#   5-10           - Save CPU, good for static cameras
#   20-30          - More responsive, higher CPU usage
#
# ROI_OVERLAP:
#   0              - Fastest, only check center point
#   50             - Balanced, half of box must be in ROI
#   80-100         - Strict, almost entire box must be in ROI
#
# ============================================

#!/bin/bash

# Example usage script for ff-rknn portable

echo "🚀 FF-RKNN Portable Example"
echo "=========================="

# Check if models exist
if [ ! -f "models/yolov8n.rknn" ]; then
    echo "❌ Model file not found: models/yolov8n.rknn"
    echo "Please ensure RKNN model files are in the models/ directory"
    exit 1
fi

echo "Available models:"
ls -la models/

echo ""
echo "Example commands:"
echo ""
echo "# Camera detection:"
echo "./ff-rknn -i /dev/video0 -f v4l2 -m models/yolov8n.rknn -track true"
echo ""
echo "# RTSP stream with mask detection:"
echo "./ff-rknn -f rtsp -i rtsp://camera_ip:554/stream -m models/yolov8n.rknn -mask-model models/face_mask.rknn -track true -mask-history 5"
echo ""
echo "# Headless mode (no UI):"
echo "./ff-rknn -f rtsp -i rtsp://camera_ip:554/stream -m models/yolov8n.rknn -track true -headless true"
echo ""

# Check system requirements
echo "System check:"
echo "Architecture: $(uname -m)"
echo "Kernel: $(uname -r)"
echo "DRM devices: $(ls /dev/dri/ 2>/dev/null || echo 'None found')"
echo "Video devices: $(ls /dev/video* 2>/dev/null || echo 'None found')"
